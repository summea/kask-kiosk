﻿
namespace Kask.DAL.Models
{
    public class JobRequirements
    {
        public int Job_ID { get; set; }
        public int Skill_ID { get; set; }
        public string Notes { get; set; }
    }
}
