﻿
namespace Kask.DAL.Models
{
    public class Expertise
    {
        public int Applicant_ID { get; set; }
        public int Skill_ID { get; set; }
    }
}
