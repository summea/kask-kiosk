﻿
namespace Kask.DAL.Models
{
    public class Work
    {
        public int Applicant_ID { get; set; }
        public int Employer_ID { get; set; }
    }
}
