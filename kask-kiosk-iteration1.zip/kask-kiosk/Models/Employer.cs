﻿
namespace Kask.DAL.Models
{
    public class Employer
    {
        public int Employer_ID { get; set; }
        public string EmployerName { get; set; }
    }
}
