using System;

namespace Kask.DAL.Models
{
    public class Applied
    {
        public int Applicant_ID { get; set; }
        public int Application_ID { get; set; }
<<<<<<< HEAD
        public int Job_ID { get; set; }
=======
        public int JobID { get; set; }
>>>>>>> origin/Application-Service
        public DateTime DateApplied { get; set; }
    }
}
