﻿
namespace Kask.DAL.Models
{
    public class Skills
    {
        public int Skill_ID { get; set; }
        public string SkillName { get; set; }
    }
}
