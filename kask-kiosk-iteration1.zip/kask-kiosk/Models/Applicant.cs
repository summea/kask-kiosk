﻿
namespace Kask.DAL.Models
{
    public class Applicant
    {
        public int Applicant_ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int SSN { get; set; }
        public char Gender { get; set; }
    }
}
