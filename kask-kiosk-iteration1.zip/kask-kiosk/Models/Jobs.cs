﻿
namespace Kask.DAL.Models
{
    public class Jobs
    {
        public int Job_ID { get; set; }
        public string JobTitle { get; set; }
    }
}
