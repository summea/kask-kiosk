﻿
namespace Kask.DAL.Models
{
    public class Applications
    {
        public int Application_ID { get; set; }
        public string ApplicationStatus { get; set; }
    }
}
