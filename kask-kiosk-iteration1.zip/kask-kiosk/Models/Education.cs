﻿
namespace Kask.DAL.Models
{
    public class Education
    {
        public int Application_ID { get; set; }
        public int School_ID { get; set; }
     }
}
