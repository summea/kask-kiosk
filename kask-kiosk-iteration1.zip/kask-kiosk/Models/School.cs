﻿
namespace Kask.DAL.Models
{
    public class School
    {
        public int School_ID { get; set; }
        public string SchoolName { get; set; }
    }
}
